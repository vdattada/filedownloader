﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using HeraImageApplication.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HeraImageApplication.Controllers
{
    [Route("File")]
    public class FileController : Controller
    {
        private IConfiguration configuration;
        public FileController(IConfiguration _configuration)
        {
            configuration = _configuration;
        }

        // GET: File
        [Route("Index")]
        public IActionResult Index()
        {
            List<FileDownloadModel> xEnumerable = new List<FileDownloadModel>();
            List<FileDirectory> fileDirectoryList = new List<FileDirectory>();

            string filesToConsider = configuration.GetSection("FilesToConsider").Value;
            
            if (string.IsNullOrEmpty(filesToConsider))
            {
                filesToConsider = "zip";
            }

            List<string> fileTypesArr = filesToConsider.Split(',').ToList();

            string initialDirectorySearchPath = configuration.GetSection("InitialDirectorySearchPath").Value;
            //Check if directory Exists
            if (Directory.Exists(initialDirectorySearchPath))
            {
                List<string> dirList = new List<string>();
                dirList.Add(initialDirectorySearchPath);
                dirList.AddRange(Directory.GetDirectories(initialDirectorySearchPath).ToList());
                
                List<string> fileList = new List<string>();

                foreach (string directoryPath in dirList)
                {
                    FileDirectory a = new FileDirectory();

                    a.DirectoryGUID = Guid.NewGuid();
                    var z = new DirectoryInfo(directoryPath);
                    
                    a.DirectoryName = z.Name;

                    var files = Directory.GetFiles(directoryPath)
                        .Where(file => fileTypesArr.Any(file.ToLower().EndsWith))
                        .ToList();

                    foreach (var item in files)
                    {
                        FileInfo t = new FileInfo(item);
                        a.FileNames.Add(t.FullName);
                    }

                    if(files.Count > 0)
                    {
                        fileList.AddRange(files);
                    }

                    fileDirectoryList.Add(a);
                }

            }

            return View(fileDirectoryList.Where(o=>o.FileNames.Count > 0));
        }

        // GET: File/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: File/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: File/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: File/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: File/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: File/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: File/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        [HttpGet]
        public async Task<IActionResult> Download(string filename)
        {
            if (filename == null)
                return Content("filename not present");


            var path = Path.Combine(
                           Directory.GetCurrentDirectory(),
                           "wwwroot", filename);

            var memory = new MemoryStream();

            using (var stream = new FileStream(path, FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }

            memory.Position = 0;
            return File(memory, GetContentType(path), Path.GetFileName(path));
        }

        private string GetContentType(string path)
        {
            var types = GetMimeTypes();
            var ext = Path.GetExtension(path).ToLowerInvariant();
            return types[ext];
        }

        private Dictionary<string, string> GetMimeTypes()
        {
            return new Dictionary<string, string>
            {
                {".txt", "text/plain"},
                {".pdf", "application/pdf"},
                {".doc", "application/vnd.ms-word"},
                {".docx", "application/vnd.ms-word"},
                {".xls", "application/vnd.ms-excel"},
                {".png", "image/png"},
                {".jpg", "image/jpeg"},
                {".jpeg", "image/jpeg"},
                {".tiff", "image/tiff"},
                {".gif", "image/gif"},
                {".csv", "text/csv"},
                {".xml", "application/xml" }
            };
        }
    }
}