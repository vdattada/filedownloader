﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeraImageApplication.Models
{
    public class FileDirectory
    {
        public FileDirectory()
        {

        }

        public Guid DirectoryGUID { get; set; }
        public string DirectoryName { get; set; }
        public List<string> FileNames { get; set; } = new List<string>();

    }
}
