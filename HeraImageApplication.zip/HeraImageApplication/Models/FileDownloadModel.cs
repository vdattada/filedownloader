﻿using System;

namespace HeraImageApplication.Models
{
    public class FileDownloadModel
    {

        public FileDownloadModel()
        {

        }
        public string FullFileName { get; set; }
        public DateTime FileCreateDate { get; set; }
    }
}